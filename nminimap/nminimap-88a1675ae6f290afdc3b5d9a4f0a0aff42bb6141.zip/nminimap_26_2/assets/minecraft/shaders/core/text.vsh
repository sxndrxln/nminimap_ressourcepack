#version 330
#define UNREL_ID

#define MAP_DEPTH 0.9999
#define MARKER_DEPTH 0.9999

#ifdef GL_ARB_shader_draw_parameters
#extension GL_ARB_shader_draw_parameters : require
#endif

#moj_import <nminimap:config.glsl>

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

flat out int custom;
out vec2 uvCoord;
flat out vec3 b_meta;
flat out vec4 box;

#moj_import <nminimap:vertex_utils.glsl>

void main() {
    custom = 0;
    uvCoord = vec2(0);
    b_meta = vec3(0);
    box = vec4(0);

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    texCoord0 = UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);

    #moj_import <nminimap:vertex_body.glsl>
#else
    vertexColor = Color;
    // Added by Ansible: macOS OpenGL rejects fragment inputs the vertex shader never writes
    custom = 0;
    uvCoord = vec2(0.0);
    b_meta = vec3(0.0);
    box = vec4(0.0);
#endif
}